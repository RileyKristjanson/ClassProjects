package kristjanson;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class HangmanDriver {
	
	static HashMap<Integer, String> map = new HashMap<>();
	static HashMap<Integer, String> Hangman = new HashMap<>();
	static String answer = "";
	
	public static void main(String[] args) {
		
		
		//Collects every word and puts it into a map
		//Step 1
		try {
		      File myObj = new File("dictionary.txt");
		      Scanner myReader = new Scanner(myObj);
		      int key= 0;
		      while (myReader.hasNextLine()) {
		        map.put(key, myReader.nextLine()); 
		        key++;
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		//asks the setup questions before the game begins
		
		String currentGame = "";
		int key = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("How many letters would you like to use?"); //step 2
		int letters = input.nextInt();
		
		for(int i = 0; i < letters; i++) {
			currentGame += "-";
		}
		
		for(int i = 0; i < map.size(); i++) {
			if(map.get(i).length() == letters) { //step 3.1
				Hangman.put(key, map.get(i));
				key++;
			}
		}
		
		
		System.out.println("How many guesses would you like?"); //step 2
		int guessesLeft = input.nextInt();
		
		String pastGuesses = "";
		int winNum = 0;
		while(guessesLeft >= 1) { //This is the main game loop that repeats every input
			////step 3.8
			System.out.println(answer);
			if(winNum == letters) { //This checks if the player has won and exits if they have
				System.out.println("You Win!");
				System.exit(-1);
			}
			System.out.println(currentGame);
			//This is the current game standings
			//step 3.3
			System.out.println("Guesses left: " + guessesLeft);
			System.out.println("Make a Guess:");
			String guess = input.next();
			if(pastGuesses.contains(guess)) {
				System.out.println("You already guessed that! Guess Again: ");
				guess = input.next();
			}
			pastGuesses += (guess + " ");
			guessesLeft--;
			
			checkElim(guess);
			//Replaces letter in the current game
			//Really over the top way of doing step 3.2
				char g = guess.charAt(0);
				if(answer != null) {
					for(int i = 0; i < answer.length(); i++) {
					
						if(answer.charAt(i) == g) {
							System.out.println("Correct!");
							winNum++;
							StringBuilder sb = new StringBuilder(currentGame);
							g = guess.charAt(0);
					        // replace character at the specified position
					        sb.setCharAt(i, g);
					        currentGame = sb.toString();
					        
						}
					}
				}	
		}
		
	}
//This checks if we should eliminate more words or give in and play normal
	public static void checkElim(String g) { //step 3.4- 3.6
		//The list with only words that dont contain the guess
		HashMap<Integer, String> cheatedList = new HashMap<>();
		
		int index = 0;
		for(int i = 0; i < Hangman.size(); i++) {
			if(Hangman.get(i) != null) {
				if(!Hangman.get(i).contains(g)) {
					cheatedList.put(index, Hangman.get(i));
				}
				index++;
			}
			
		}
		
		if(!cheatedList.isEmpty()) {
			Hangman = cheatedList;
			
			
		} else {
			answer = Hangman.get((int) Math.random() * Hangman.size());
			
		}
		
		
	}
}
