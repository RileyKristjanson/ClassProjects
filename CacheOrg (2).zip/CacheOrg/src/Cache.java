
/**
 * Class implementing a basic cache with a configurable size and associativity.
 * 
 * The cache is backed-up by a "Memory" object which actually stores stores the values -- on a cache miss, the Memory should be accessed.
 * 
 */
public class Cache implements ReadOnlyCache
{
	private Memory m_memory;
	private int blockCount;
	private int bytesPerBlock;
	private int associativity;
	private boolean[] Valid;
	private int[] Tag;
	private byte[][] Data;


	/**
	 * Constructor
	 * @param memory - An object implementing the Memory functionality.  This should be accessed on a cache miss
	 * @param blockCount - The number of blocks in the cache.
	 * @param bytesPerBlock - The number of bytes per block in the cache.
	 * @param associativity - The associativity of the cache.  1 means direct mapped, and a value of "blockCount" means fully-associative.
	 */
	public Cache(Memory memory, int blockCount, int bytesPerBlock, int associativity)
	{
		m_memory = memory;
		
		this.blockCount = blockCount;
		this.associativity = associativity;
		this.bytesPerBlock = bytesPerBlock;
		Valid = new boolean[blockCount];
		Tag = new int[blockCount];
		Data = new byte[blockCount][bytesPerBlock];
	}

	/**
	 * Method to retrieve the value of the specified memory location.
	 * 
	 * @param address - The address of the byte to be retrieved.
	 * @return The value at the specified address.
	 */
	public byte load(int address)
	{
		// TODO: implement the logic to perform the specified load
		// using caching logic.  This implementation does not do any caching,
		// it just immediately accesses memory, and is not correct.
		if(Valid[Index(address)] && Tag[Index(address)] == Tag(address)) {
			return Data[Index(address)][Offset(address)];
		} else {
			Data[Index(address)] = m_memory.read(BlockAddress(address), bytesPerBlock);
			Valid[Index(address)] = true;
			Tag[Index(address)] = Tag(address);
			return (Data[Index(address)][Offset(address)]);
		}
		

	}
	
	private int Index(int address) {
		address = address >> (int) Math.log(bytesPerBlock);
		return ((address >> (int) Math.log(blockCount)) / bytesPerBlock) % blockCount;
		//blockCount % ((address >> (int) Math.log(blockCount)) / bytesPerBlock)
	}
	
	private int Tag(int address) {
		return (address >> (int) Math.log(bytesPerBlock) + (int) Math.log(bytesPerBlock));
		
	}
	
	private int Offset(int address) {
		int mask = 0;
			mask = (2 << (int) Math.log(bytesPerBlock)) -1;
		//System.out.println(Integer.toBinaryString(mask));
		return (address & mask);
	}
	
	private int BlockAddress(int address) {
		return address - Offset(address);
	}
	
	
}
