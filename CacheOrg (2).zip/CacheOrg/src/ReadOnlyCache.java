
public interface ReadOnlyCache
{
	public byte load(int address);
}
