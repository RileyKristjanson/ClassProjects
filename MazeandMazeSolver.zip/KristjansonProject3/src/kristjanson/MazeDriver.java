package kristjanson;

public class MazeDriver {

	public static void main(String[] args) {
		Maze mazeTest = new Maze(31, 31);
	}
	
}
