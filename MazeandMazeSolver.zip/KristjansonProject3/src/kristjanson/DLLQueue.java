package kristjanson;

import java.util.LinkedList;

public class DLLQueue<T> implements Queue<T> {

	private LinkedList<T> queue;
	
	public DLLQueue(){
		queue = new LinkedList<T>();
	}
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return queue.size();
	}

	@Override
	public boolean isEmpty() {
		if(queue.size() != 0) {
			return false;
		}
		return true;
	}

	@Override
	public T first() {
		return queue.get(0);
	}

	@Override
	public void enqueue(T v) {
		queue.addLast(v);
		
	}
	

	@Override
	public T dequeue() {
		T ret = queue.getFirst();
		queue.removeFirst();
		return ret;
		
	}
	
	@Override
	public String toString() {
		return queue.toString();
	}
	
	

}
