package kristjanson;

import java.util.ArrayList;
import java.util.Collections;

import edu.du.dudraw.DUDraw;

// Worked with Cass Sherman
// 5/7/2021

public class Maze {

	private enum cellValue { Wall, Open, Explored }
	
	int width;
	int height;
	
	private cellValue[][] arr;
	
	
	public Maze(int w, int h) {
			
		width = w;
		height = h;
		
		DUDraw.setCanvasSize(500, 500);
		DUDraw.setXscale(0,width);
		DUDraw.setYscale(0, height);
		DUDraw.enableDoubleBuffering();
		
		
		arr = new cellValue[width][height];
		
		for(int i = 0; i < arr.length; i++) {
			for(int j = 0; j < arr[0].length; j++) {
				arr[i][j] = cellValue.Wall;
			}
		}
		draw();
		generateMaze();
		solveMaze();
	}
	
	public void draw() {
		DUDraw.clear();
		
		for(int i = 0; i < width; i++) {
			for(int j = 0; j < height; j++) {
				if (arr[i][j] == cellValue.Wall) {
					DUDraw.setPenColor();
				} else if (arr[i][j] == cellValue.Explored) {
					DUDraw.setPenColor(0, 255, 0);
				} else {
					DUDraw.setPenColor(255, 255, 255);
				}
				Cell current = new Cell(i, j);
				DUDraw.filledSquare(j + .5, i + .5, .5);
			}
			
		}
		DUDraw.pause(10);
		DUDraw.show();
	}
	
	public void generateMaze() {
		
		SLLStack<Cell> stack = new SLLStack<Cell>();
//		current = (1,1) 
		Cell current = new Cell(1,1);
//				set the current to Open
		arr[1][1] = cellValue.Open;
//				push current on the stack
		stack.push(current);
//				while stack is not empty
		while (!stack.isEmpty()) {
//			pop the stack into current
			current = stack.pop();

			ArrayList<Cell> neighbors = new ArrayList<Cell>();
			
			int north = current.col + 2;
			int south = current.col - 2;
			int west = current.row - 2;
			int east = current.row + 2;
			int x = current.row;
			int y = current.col;
			boolean CheckN = north < height && north > 0;
			boolean CheckS = south > 0 && south < height;
			boolean CheckE = east < width && east > 0;
			boolean CheckW = west > 0 && west < width;
			// opens neighbors and middle cells and adds neighbors to list
			// upper
			if (CheckN) {
				if (arr[x][north].equals(cellValue.Wall)) {
					Cell n = new Cell(x, north);
					// add neighbor to neighbors and set open
					arr[x][north] = cellValue.Open;
					neighbors.add(n);
					// set middle cell open
					arr[x][y + 1] = cellValue.Open;
				}
			}
			// Lower
			if (CheckS) {
				if (arr[x][south].equals(cellValue.Wall)) {
					Cell n = new Cell(x, south);
					arr[x][south] = cellValue.Open;
					neighbors.add(n);
					arr[x][y - 1] = cellValue.Open;
				}
			}
			// Left
			if (CheckW) {
				if (arr[west][y].equals(cellValue.Wall)) {
					Cell n = new Cell(west, y);
					arr[west][y] = cellValue.Open;
					neighbors.add(n);
					arr[x - 1][y] = cellValue.Open;
				}
			}
			// Right
			if (CheckE) {
				if (arr[east][y].equals(cellValue.Wall)) {
					Cell n = new Cell(east, y);
					arr[east][y] = cellValue.Open;
					neighbors.add(n);
					arr[x + 1][y] = cellValue.Open;
				}
			}
			// shuffle/randomize the arrayList neighbors
			Collections.shuffle(neighbors);
			// push all the content of neighbors on the stack
			for (Cell c : neighbors) {
				stack.push(c);
			}
			// draw updates
			draw();
		}
	}


	
	public void solveMaze() {
//		start = (1,1)
		Cell current = new Cell(1,1);
//				goal = (height-2, width-2)
		Cell goal = new Cell(height -2, width -2);
		
		arr[1][1] = cellValue.Explored;
//				
		DLLQueue<Cell> queue = new DLLQueue<Cell>();
//				set the currentCell to Explored
//				enqueue currentCell on the queue
//				while queue is not empty
//				     dequeue the queue into currentCell
//				     if currentCell is the goal then return (we found the target)
//				     foreach neighboring Cell n (those are cells that are one step away) that is not Explored: 
//				           set neighbor n to Explored and enqueue it on the queue. 
		queue.enqueue(current);
		
		while(!queue.isEmpty()) {
			
			current = queue.dequeue();
			
			if(goal.col == current.col && goal.row == current.row) {
				System.out.println("Maze Solved!");
				System.exit(-1);
			}
			
			int north = current.col + 1;
			int south = current.col - 1;
			int west = current.row - 1;
			int east = current.row + 1;
			int x = current.row;
			int y = current.col;
			boolean CheckN = north < height && north > 0;
			boolean CheckS = south > 0 && south < height;
			boolean CheckE = east < width && east > 0;
			boolean CheckW = west > 0 && west < width;
			// opens neighbors and middle cells and adds neighbors to list
	
			
			if (CheckN) {
				if (arr[x][north].equals(cellValue.Open)) {
					Cell n = new Cell(x, north);
					// add neighbor to neighbors and set open
					arr[x][north] = cellValue.Explored;
					queue.enqueue(n);
					// set middle cell open
					arr[x][y + 1] = cellValue.Explored;
				}
			}
	
			if (CheckS) {
				if (arr[x][south].equals(cellValue.Open)) {
					Cell n = new Cell(x, south);
					arr[x][south] = cellValue.Explored;
					queue.enqueue(n);
					arr[x][y - 1] = cellValue.Explored;
				}
			}
	
			if (CheckW) {
				if (arr[west][y].equals(cellValue.Open)) {
					Cell n = new Cell(west, y);
					arr[west][y] = cellValue.Explored;
					queue.enqueue(n);
					arr[x - 1][y] = cellValue.Explored;
				}
			}
			if (CheckE) {
				if (arr[east][y].equals(cellValue.Open)) {
					Cell n = new Cell(east, y);
					arr[east][y] = cellValue.Explored;
					queue.enqueue(n);
					arr[x + 1][y] = cellValue.Explored;
				}
			}
			draw();
		}
//				end
	}
	
	public class Cell {
		int row;
		int col;
		public Cell(int r, int c) {
			row = r;
			col = c;
		}
		
		public String toString() {
			return (row + " " + col);
		}
	}
}
