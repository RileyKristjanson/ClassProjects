package kristjanson;

public class SLLStack<T> implements Stack<T> {
	// the variable stack is a singly-linked list storing the stack. For efficiency,
	// the top of the stack is stored at the head of the SLL.
	private SinglyLinkedList<T> stack;
	public SLLStack() {
		stack = new SinglyLinkedList<T>();
	}
	@Override
	public int size() {
		return stack.size();
	}
	@Override
	public boolean isEmpty() {
		return stack.isEmpty();
	}
	@Override
	// stacks are LIFO, so add new elements to the top of the stack, 
	// stored at the head of the SLL
	public void push(T v) {
		stack.addFirst(v);
	}
	@Override
	// stacks are LIFO, so remove elements from the top of the stack,
	// stored at the head of the SLL
	public T pop() {
		return stack.removeFirst();
	}
	@Override
	public T top() {
		return stack.get(0);
	}
}
