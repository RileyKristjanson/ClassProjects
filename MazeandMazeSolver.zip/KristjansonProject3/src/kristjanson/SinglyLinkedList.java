package kristjanson;


public class SinglyLinkedList<T> implements Comparable<T>{
	private Node head;
	private int size;
	public SinglyLinkedList() {
		this.head = null;
		this.size = 0;
	}
	
	//adds to the front of the list and shifts the head
	public void addFirst(T v) {
		try {
			// create a new node
			Node newNode = new Node(v);
			// new node must point to the original head node
			newNode.next = this.head;
			// head must point to the new node
			this.head = newNode;
			// if list is empty, exception catches and instead make the new node the head
		} catch (NullPointerException e) {
			this.head = new Node(v);
		}
		this.size++;
	}
	
	// add node to end of list
	public void addLast(T v) {
		Node newNode = new Node(v);
		Node current = null;
		try {
			current = head;
			for (int i = 0; i < size; i++) {
				if (current != null && current.next != null) {
					current = current.next;
				}
			}
			current.next = newNode;
		} catch (NullPointerException e) {
			head = newNode;
		}
		this.size++;
	}

	//Returns a boolean true if list is empty
	public boolean isEmpty() {
		if (size == 0) {
			return true;
		} else
			return false;
	}
	
	//Removes at the 'v' index
	public T removeAtIndex(int v) {
		Node current = head;
		Node last = null;
		try {
			
			if (v > 0) {
				for (int i = 0; i < size; i++) {
					if (i == v) {
						last.next = current.next;
						size--;
						return current.value;
					}
					last = current;
					current = current.next;
				}
				
			} else if (v == 0) {
				head = head.next;
				size--;
				return current.value;
			}
		} catch (NullPointerException e) {
			
		}
		System.err.println("that index is out of bounds");
		return null;
	}
	
	//Getter for size
	public int size() {
		return size;
	}
	
	//removes the first node and shifts head
	public T removeFirst() {
		return removeAtIndex(0);
	}
	//removes last node
	public T removeLast() {
		return removeAtIndex(size - 1);
	}
	
	//gets the value of i
	public T get(int i) {
		Node current = head;
		int v = 0;
		try {
			
			for (int j = 0; j < size; j++) {
				if (v == i) {
					return current.value;
				}
				current = current.next;
				v++;
			}
		} catch (NullPointerException e) {
			System.out.println("out of bounds or is null");
		}
		System.out.println("null is out of bounds");
		return null;
	}
	
		
	
	@Override
	public String toString() {
		String result = "List contents: ";
		Node current = head;
		while (current != null) {
			result = result + current.toString() + " ";
			current = current.next;
		}
		return result;
	}
	private class Node {
		private T value;
		private Node next;
		public Node(T v) {
			this.value = v;
			this.next = null;
		}
		@Override
		public String toString() {
			return value.toString();
		}
	}
	@Override
	public int compareTo(T o) {
		// TODO Auto-generated method stub
		return 0;
		
		
	}
	
	public boolean remove(T v) {
		Node current = head;
		int index = 0;
		for (int i = 0; i < size; i++) {
			try {
				if (((Comparable<T>) current.value).compareTo(v) == 0) {
					removeAtIndex(index);
					return true;
				}
				index++;
				current = current.next;
			} catch (NullPointerException e) {
				System.err.println("returning false as a null value was reached instead of the requested value");
			}
		}
		System.err.println("returning false as the value did not exist");
		return false;
	}
}