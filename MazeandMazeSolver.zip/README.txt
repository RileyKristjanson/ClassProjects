You must first add the DUDRAW.exe file to your available libraries in your IDE for this to operate correctly. Depending on
your machine you may also need to reformat the import statement to match your folder location. This is because I am using
university software, which has similar commands to commonly used java gui packages.