package kristjansonProject5;

import java.io.Serializable;
import java.util.*;

import java.util.ArrayList;


public class Filesystem implements Serializable {

	Node root;
	Node currentDirectory;
	
	public Filesystem() { //constructor
		//Called it system bc it looks better. This could be subbed for ""
		root = new Node("System", null, true);
		currentDirectory = root;
	}
	
	public void checkMakeFile(String nm) throws Exception{ //check if there is already a file like that
		for(Node n: currentDirectory.children()) {
			if(n.name == nm) {
				throw new IllegalArgumentException("That already exists");
			}
		}
		
	}
	
	public void ls() { //lists whats in the current directory
		
		for(Node c: currentDirectory.children) {
			System.out.println(c.name + " ");
		}
	}
	
	public void mkdir(String dirname) throws Exception{ // makes a directory in current directory
		
		checkMakeFile(dirname);
		currentDirectory.appendChild(dirname, true);
	}
	
	public void touch(String name) throws Exception{ //makes a file in the current directory
			
			checkMakeFile(name);
			currentDirectory.appendChild(name, false);
		}
	

	public Node isValid(String name) { //checks if there is name in the directory and if so returns the node
		boolean bool = false;
		for (Node c : currentDirectory.children) {
			if (c.name.equals(name)) {
				bool = true;
				return c;
			}
		}
		if (!bool) {
			throw new IllegalArgumentException( "This is not in the Current Directory");
		}
		return null;
	}
	
	public void cd(String name) { //this is how you navigate around the filesystem. typing .. goes to the parent
		Node n = currentDirectory;
		if(name.contains("..") && n.parent != null) {
			currentDirectory = n.parent;
		} else {
			n = isValid(name);
			if (!n.isDirectory) {
				throw new IllegalArgumentException( "This is a file");
			}
			currentDirectory = n;
		}
		
	}
	
	public void rm(String fileName) throws Exception { // this removes the given file
		Node n = isValid(fileName);
		
		if(n.isDirectory()) {
			throw new IllegalArgumentException("Thats a directory");
		}
		n.parent.children.remove(n);
			
		
	}
	
	public void rmdir(String fileName) throws Exception { //this removes the given directory
		Node n = isValid(fileName);
		
		if(!n.isDirectory()) {
			throw new IllegalArgumentException("Thats a file");
		}
		if(!n.children.isEmpty()) {
			throw new IllegalArgumentException("This directory is not empty");
		}
		n.parent.children.remove(n);
	}
	
	
	public String tree() { //this pretty prints the tree with help from the helper to count how much indentation we need
		StringBuilder sb = new StringBuilder();
		helper(sb, currentDirectory, 0);
		return sb.toString();
	}
	
	//In order traversal
	public void helper(StringBuilder sb, Node n, int tabs) {
		
		if(n == null) {
			return;
		}
			
		for(int i = 0; i < tabs; i++) {
			sb.append(" ");
		}
		
		sb.append(n.name + "\n");
		if(n.isDirectory()) {
			
			for(int i = 0; i < n.children().size(); i++) {
				
				helper(sb, n.children.get(i), tabs +1);
			}
		}
	}
	
//		Add each string to a stack (each name in the nodes leading up to the root).
//		Create a StringBuilder object and append the entries in the stack to the StringBuilder.
//		Print the StringBuilder using its toString() method.
	
	public String pwd() { //This prints out the slash print of your current directory
		
		Stack<String> print = new Stack<String>();
		StringBuilder sb = new StringBuilder();
		Node temp = currentDirectory;
		
		while(temp != null) {
			
			print.push(temp.name);
			temp = temp.parent;
		}
		
		while(print.size() != 0) {
			sb.append(print.pop() + "/");
		}
		return sb.toString();
	}
	
	public class Node implements Serializable {
		
		String name;
		private ArrayList<Node> children = new ArrayList<Node>();
		private Node parent;
		private Boolean isDirectory;
		
		public Node(String nam, Node par, boolean isDirect) {
			name = nam;
			parent = par;
			isDirectory = isDirect;
		}
		
		public boolean isDirectory() {
			return isDirectory;
		}
		
		public ArrayList<Node> children() {
			return children;
		}
		
		public void appendChild(String nam, boolean isDir) {
			Node node = new Node(nam, this, isDir);
			children.add(node);
		}
		
		public boolean isRoot() {
			return parent == null;
		}
	}
}
