package kristjansonProject5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) throws Exception {

		
		Scanner scan = new Scanner(System.in);
		Filesystem fs = new Filesystem();
		try { //this attempts to set up the file and the input/output streams
			FileInputStream fileIn = new FileInputStream("fs.dat");
			ObjectInputStream objIn = new ObjectInputStream(fileIn);
			fs = (Filesystem) objIn.readObject();//Makes objs into files
			fileIn.close();
		} catch (IOException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}
		
		boolean quit = false;
		//Loop that continues to run until it is exitted by the user saying quit
		while(!quit) {
			//Asks user input and pauses the loop until we get it
			String Input = scan.next();
			//Asks if the user wants to quit and exits if they do
			if(Input.contains("quit") || Input.contains("Quit")) {
				System.err.println("Program Exit");
				quit = true;
			}
			try { //Attempts to find the command and if not throws errors from the filesystem
				if(Input.contains("mkdir")) { //asks if the command is present
					fs.mkdir(Input.substring(Input.indexOf("<")  + 1,Input.indexOf(">"))); //makes a substring of only the name and inputs it
					Input = ""; // erases the input so we can move on
				} else if(Input.contains("touch")) {
					fs.touch(Input.substring(Input.indexOf("<")  + 1,Input.indexOf(">")));
					Input = "";
				} else if (Input.contains("cd")) {
					fs.cd(Input.substring(Input.indexOf("<")  + 1,Input.indexOf(">")));
					Input = "";
				} else if(Input.contains("rmdir")) {
					fs.rmdir(Input.substring(Input.indexOf("<")  + 1,Input.indexOf(">")));
					Input = "";
				} else if(Input.contains("rm")) {
					fs.rm(Input.substring(Input.indexOf("<")  + 1,Input.indexOf(">")));
					Input = "";
				} else if(Input.contains("ls")) {
					fs.ls();
					Input = "";
				} else if(Input.contains("tree")) {
					System.out.println(fs.tree());
				} else if(Input.contains("pwd")) {
					System.out.println(fs.pwd());
				} 
			} catch (IllegalArgumentException e) {
				System.err.println(e);
			} catch (java.lang.StringIndexOutOfBoundsException e) {
				System.err.println(e);
			}
			
		}
		
		try { // attempts to get streams
			FileOutputStream fileOut = new FileOutputStream("fs.dat");
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(fs); // writes the objects
			objOut.close(); //closes out our streams
			fileOut.close();
		} catch (IOException e) {
			System.out.println(e);
		}

	}

}
