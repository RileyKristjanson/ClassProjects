To run the GUI correctly you must first create the Henry bookstore SQL database and then change the root and password to connect to your 
new local SQL database