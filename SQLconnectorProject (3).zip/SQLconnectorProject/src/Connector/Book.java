package Connector;

public class Book { //hold the info from our querys so we can reference them later, also we needed to override toString

	private String bookCode;
	String bookName;
	double bookPrice;
	
	
	public void setAll(String c, String n, double p) {
		this.setBookCode(c);
		this.bookName = n;
		this.bookPrice = p;
	}
	
	public void setCode(String c) {
		this.setBookCode(c);
	}
	
	public void setName(String n) {
		this.bookName = n;
	}
	
	public String toString() {
		
		return bookName;
	}
	
	public double getPrice() {
		return bookPrice;
	}

	public String getBookCode() {
		return bookCode;
	}

	public void setBookCode(String bookCode) {
		this.bookCode = bookCode;
	}
	

}
