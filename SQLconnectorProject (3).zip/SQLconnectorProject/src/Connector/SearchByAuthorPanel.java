package Connector;


import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;


class SearchByAuthorPanel extends JPanel {
	//setting up our variables and lists for boxes
	  private JComboBox<ArrayList> authorComboBox1;
	  private JComboBox<ArrayList> authorComboBox2;
	  private JTextField searchTextField;
	  private JTable branchInfo;
	  Dimension buttonSize1 = new Dimension(300,20);
	  Dimension buttonSize2 = new Dimension(700,20);
	  henryDao DAO = new henryDao();
	  private int authorNum = 1;
		ArrayList<Author> authorArray = new ArrayList<>();
		ArrayList<Book> bookArray = new ArrayList<>();
		String[][] branchArray = new String[5][3];
		
	  public SearchByAuthorPanel() {
		  //setup of the Author box, and insertion of the data on the first open
		authorArray = DAO.getAuthorArray();
	    authorComboBox1 = new JComboBox(authorArray.toArray());
	    authorComboBox1.setPreferredSize(buttonSize1);
	    authorNum = authorArray.get(authorComboBox1.getSelectedIndex()).getNum();
		  
	    //setup of the book box, and insertion of the data on the first open		
	    bookArray = DAO.getBooksByAuthor(authorNum);
	    authorComboBox2 = new JComboBox(bookArray.toArray());
	    authorComboBox2.setPreferredSize(buttonSize2);

		  //setup of the price box, and insertion of the data on the first open
	    searchTextField = new JTextField(" $" + bookArray.get(0).getPrice() + "  "); //first population of initial book
	    searchTextField.setEditable(false);
	    
		//setup of the branch table, and insertion of the data on the first open
	    branchArray = DAO.getBranch(bookArray.get(0).getBookCode());
	    String[][] data = branchArray;
	    String columnNames[] = {"Branch Name", "Branch Location", "Num on Hand"};
	    DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
	    branchInfo = new JTable(tableModel);
	    tableModel.setDataVector(data, columnNames);

	    
	    
	    authorComboBox1.addActionListener(new ActionListener() { //listener for user changing first box
	      @Override
	      public void actionPerformed(ActionEvent e) {
	        // Add action code here
	    	//population of the Author box after a change after a change to the Author box
	  		  authorNum = authorArray.get(authorComboBox1.getSelectedIndex()).getNum();
	    	  authorComboBox2.removeAllItems();
	    	  bookArray = DAO.getBooksByAuthor(authorNum);
		      authorComboBox2.setModel(new DefaultComboBoxModel(bookArray.toArray()));
		     
		      //population of the book box after a change to the Author box
		      if(authorComboBox2.getSelectedIndex() >= 0) { //populates the price field
	    		  searchTextField.setText(" $" + bookArray.get(authorComboBox2.getSelectedIndex()).getPrice() + "  ");
			      branchArray = DAO.getBranch(bookArray.get(authorComboBox2.getSelectedIndex()).getBookCode());
			      tableModel.setDataVector(branchArray, columnNames); // Updates the table with the new data
	    		  
	    	  } else {
	    		  searchTextField.setText(" $" + bookArray.get(0).getPrice() + "  ");
	    		  branchArray = DAO.getBranch(bookArray.get(0).getBookCode());
			      tableModel.setDataVector(branchArray, columnNames); // Updates the table with the new data
	    	  }
	    	  
	      }
	    });

	    authorComboBox2.addActionListener(new ActionListener() { //listener for user changing second box
	      @Override
	      public void actionPerformed(ActionEvent e) {
	        // Add action code here
		    	//population of the book box after a change to the book box
	    	  if(authorComboBox2.getSelectedIndex() >= 0) { //populates the price field
	    		  searchTextField.setText(" $" + bookArray.get(authorComboBox2.getSelectedIndex()).getPrice() + "  ");
	    		  branchArray = DAO.getBranch(bookArray.get(authorComboBox2.getSelectedIndex()).getBookCode());
			      tableModel.setDataVector(branchArray, columnNames); // Updates the table with the new data
	    	  } else {
	    		  searchTextField.setText(" $" + bookArray.get(0).getPrice() + "  ");
	    		  branchArray = DAO.getBranch(bookArray.get(0).getBookCode());
			      tableModel.setDataVector(branchArray, columnNames); // Updates the table with the new data
	    	  }
	    	
	    	  
	      }
	    });

	    add(authorComboBox1);
	    add(authorComboBox2);
	    add(searchTextField);
	    add(branchInfo);
	  }
}