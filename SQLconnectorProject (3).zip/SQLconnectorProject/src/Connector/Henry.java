package Connector;

//Riley Kristjanson and Cass Sherman 2/15/2023
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Henry extends JFrame {
  private JTabbedPane tabbedPane;
  private JPanel searchByAuthorPanel;
  private JPanel searchByCategoryPanel;
  private JPanel searchByPublisherPanel;
  henryDao DAO = new henryDao();
  
  public Henry() {
    super("Book Search");
    tabbedPane = new JTabbedPane();
    searchByAuthorPanel = new SearchByAuthorPanel();
    searchByCategoryPanel = new SearchByCategoryPanel();
    searchByPublisherPanel = new SearchByPublisherPanel();
    
    tabbedPane.addTab("Search By Author", searchByAuthorPanel);
    tabbedPane.addTab("Search By Category", searchByCategoryPanel);
    tabbedPane.addTab("Search By Publisher", searchByPublisherPanel);

    add(tabbedPane, BorderLayout.CENTER);
  }

  public static void main(String[] args) {
    Henry mainFrame = new Henry();
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.setPreferredSize(new Dimension(800, 500));
    mainFrame.pack();
    mainFrame.setVisible(true);
  }
}

