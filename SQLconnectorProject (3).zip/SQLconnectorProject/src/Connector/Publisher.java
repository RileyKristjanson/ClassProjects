package Connector;

public class Publisher { //hold the info from our querys so we can reference them later, also we needed to override toString

	private String publisherCode;
	private String publisherName;
	private String publisherCity;
	
	public void setAll(String c, String n, String ci) {
		this.publisherCode = c;
		this.publisherName = n;
		this.publisherCity = c;
	}
	public String getPublisherCode() {
		return publisherCode;
	}
	public void setPublisherCode(String publisherCode) {
		this.publisherCode = publisherCode;
	}
	public String getPublisherName() {
		return publisherName;
	}
	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}
	public String getPublisherCity() {
		return publisherCity;
	}
	public void setPublisherCity(String publisherCity) {
		this.publisherCity = publisherCity;
	}
	
	public String toString() {
		return this.publisherName;
	}
	
	
}
