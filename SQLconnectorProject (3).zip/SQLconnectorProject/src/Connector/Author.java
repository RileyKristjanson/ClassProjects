package Connector;


//Authors job is to simply hold onto the 3 pieces of information.  The Author 
	//class might need toStrings or getters to provide the pieces of information to the GUI.  That is, 
	//you will be returning a List/Vector of Authors and all the relevant author information will be 
	//inside that class. 
public class Author{

	String firstName;
	String lastName;
	int number;
	
	public void setAll(String fn, String ln, int num) {
		this.firstName = fn;
		this.lastName = ln;
		this.number = num;
	}

	public void setFirstName(String name) {
		this.firstName = name;
	}
	
	public void setLasttName(String name) {
		this.lastName = name;
	}
	
	public void setFirstName(int num) {
		this.number = num;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public int getNum() {
		return this.number;
	}
	
	public String toString() {
			
			return firstName + " " + lastName;
		}
}
