package Connector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
public class henryDao {
	protected static ArrayList<Author> authors = new ArrayList<>();
	static Connection conn;
	
	public henryDao() { //constructor to set up our connection
		String db_url = "jdbc:mysql://localhost/comp3421";
		String user = "root";
		String pass = "krist0853";
		try {
			
			conn = DriverManager.getConnection(db_url, user, pass);			
			
		} catch (SQLException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<Author> getAuthorArray() { //grabs the author array
		return getAuthorData(conn);
	}
	
	
	public static ArrayList<Publisher> getPublisher() { //gets the array of publisher objects
		Statement stmt;
		ArrayList<Publisher> pubs = new ArrayList<>();
		
		try {
			stmt = conn.createStatement();
			String sql = "SELECT * FROM HENRY_PUBLISHER where PUBLISHER_CODE in (Select publisher_code from henry_book)";
			ResultSet rs = stmt.executeQuery(sql);
		
			// list of authors
			while (rs.next()) {
				
				Publisher temp = new Publisher();
				String fn = rs.getString("PUBLISHER_CODE");
				String ln = rs.getString("PUBLISHER_NAME");
				String n = rs.getString("CITY");
				temp.setAll(fn, ln, n);
					
				pubs.add(temp);
			}
		} catch (
		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pubs;
	}
	
	public static ArrayList<String> getType() { //get the arraylist of the category of books
		Statement stmt;
		ArrayList<String> pubs = new ArrayList<>();
		
		try {
			stmt = conn.createStatement();
			String sql = "SELECT distinct Type FROM henry_book";
			ResultSet rs = stmt.executeQuery(sql);
		
			// list of authors
			while (rs.next()) {
				
				String fn = rs.getString("Type");
					
				pubs.add(fn);
			}
		} catch (
		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pubs;
	}
	
	public ArrayList<Book> getBooksByAuthor(int authNum) { //get the books by the author id
		Statement stmt;
		ArrayList<Book> temp = new ArrayList<>();

			try {
				stmt = conn.createStatement();
				String sql = "SELECT BOOK_CODE, TITLE, PRICE FROM henry_book WHERE BOOK_CODE in (SELECT BOOK_CODE FROM henry_wrote WHERE AUTHOR_NUM = " + authNum + ")";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					Book b = new Book();
					String bn = rs.getString("TITLE");
					String code = rs.getString("BOOK_CODE");
					double price = rs.getDouble("PRICE");
					
					b.setAll(code, bn, price);
					System.out.println(bn + " " + code);
					temp.add(b);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		
		return temp;
	}
	
	public ArrayList<Book> getBooksByPub(String Auth) { //get the books the publisher has published
		Statement stmt;
		ArrayList<Book> temp = new ArrayList<>();

			try {
				stmt = conn.createStatement();
				String sql = "SELECT distinct BOOK_CODE, TITLE, PRICE FROM henry_book join henry_publisher on henry_book.publisher_CODE = "
						+ "henry_publisher.publisher_CODE WHERE henry_publisher.PUBLISHER_CODE = '" + Auth + "'";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					Book b = new Book();
					String bn = rs.getString("TITLE");
					String code = rs.getString("BOOK_CODE");
					double price = rs.getDouble("PRICE");
					
					b.setAll(code, bn, price);
					System.out.println(bn + " " + code);
					temp.add(b);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		
		return temp;
	}
	
	public ArrayList<Book> getBooksByType(String type) { //get books by a certain type
		Statement stmt;
		ArrayList<Book> temp = new ArrayList<>();

			try {
				stmt = conn.createStatement();
				String sql = "Select distinct Title, book_code, Price from henry_book where type = '" + type + "'";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					Book b = new Book();
					String bn = rs.getString("TITLE");
					String code = rs.getString("BOOK_CODE");
					double price = rs.getDouble("PRICE");
					
					b.setAll(code, bn, price);
					System.out.println(bn + " " + code);
					temp.add(b);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		
		return temp;
	}
	
	public String[][] getBranch(String booknum) { //get the branch data to fill into the table
		Statement stmt;
		//ArrayList<branch> temp = new ArrayList<>();
		String[][] tempGlobal = new String[5][3];
		try {
			stmt = conn.createStatement();
			String sql = "select ON_Hand, BRANCH_NAME, BRANCH_LOCATION FROM henry_inventory join henry_branch on "
					+ "henry_inventory.branch_num = henry_branch.BRANCH_NUM where book_code = '" + booknum + "'";
			ResultSet rs = stmt.executeQuery(sql);
			int i = 0;
			while(rs.next()) {
				branch tbranch = new branch();
				int onHand = rs.getInt("ON_Hand");
				//int bNum = rs.getInt("BRANCH_NUM");
				String bName = rs.getString("BRANCH_NAME");
				String bLoc = rs.getString("BRANCH_LOCATION");
				tbranch.setAll(onHand, bName, bLoc);
				//temp.add(tbranch);
				String[] temp = {bName, bLoc, "" + onHand};
				tempGlobal[i] = temp;
				i++;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(tempGlobal);
		return tempGlobal;
		
	}
	
	//getAuthorData
	//This would execute a 
	//	query on the database which brings back the author information. This information probably 
	//	includes author number as well as first and last names.  Thus, you won!t be able to simply 
	//	return a list/vector of a built-in type like String or Integer, since you have at least 3 pieces of 
	//	information to return. 
	private static ArrayList<Author> getAuthorData(Connection conn) {
		Statement stmt;
		ArrayList<Author> authors = new ArrayList<Author>();
		
		try {
			stmt = conn.createStatement();
			String sql = "SELECT * FROM henry_author Where author_num in(Select author_num from henry_wrote)";
			ResultSet rs = stmt.executeQuery(sql);
		
			// list of authors
			while (rs.next()) {
				
				Author temp = new Author();
				String fn = rs.getString("author_first");
				String ln = rs.getString("author_last");
				int n = rs.getInt("author_num");
				temp.setAll(fn, ln, n);
					
				System.out.println("fn: " + fn + ", ln " + ln + ", num " + n);
				authors.add(temp);
			}
		} catch (
		SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return authors;
	}
	
	
}
