package Connector;

public class branch { //hold the info from our querys so we can reference them later, also we needed to override toString

	private int onHand;
	private int branchNum;
	private String branchName;
	private String branchLocation;
	

	public void setAll(int h, String na, String l) {
		this.setOnHand(h);
		this.setBranchName(na);
		this.setBranchLocation(l);
	}

	public int getOnHand() {
		return onHand;
	}

	public void setOnHand(int onHand) {
		this.onHand = onHand;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public int getBranchNum() {
		return branchNum;
	}

	public void setBranchNum(int branchNum) {
		this.branchNum = branchNum;
	}

	public String getBranchLocation() {
		return branchLocation;
	}

	public void setBranchLocation(String branchLocation) {
		this.branchLocation = branchLocation;
	}
	
	public String toString() {
		return branchName + "     " + branchNum + "    " + onHand;
	}

}
